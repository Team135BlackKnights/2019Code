package frc.robot.subsystems;

	import com.ctre.phoenix.motorcontrol.ControlMode;
	import com.ctre.phoenix.motorcontrol.NeutralMode;
	import com.ctre.phoenix.motorcontrol.can.TalonSRX;
	import com.ctre.phoenix.motorcontrol.can.VictorSPX;

	import edu.wpi.first.wpilibj.Compressor;
	import edu.wpi.first.wpilibj.command.Subsystem;
	import edu.wpi.first.wpilibj.Solenoid;

	import frc.robot.RobotMap;

public class Intake extends Subsystem 
{

    public static Intake instance;
    
    public TalonSRX IntakeElbow;
	public VictorSPX IntakeWheels;

	public Solenoid solenoid;
	public Compressor compressor;

	public boolean leftInverted = false; public boolean rightInverted = false; 

	private boolean compressorState = true;

    private Intake()
    {
  		InitializeMotors();
   		InitializePneumatics();
    }

    public static Intake InitializeIntake()
	{
		if (instance == null)
		{
			instance = new Intake();
		}
		return instance; 
	}
	
	public void InitializeMotors()
	{
		IntakeElbow = new TalonSRX(RobotMap.Robot.Intake.ELBOW_TALON);
		IntakeWheels = new VictorSPX(RobotMap.Robot.Intake.WHEEL_VICTOR);

		IntakeElbow.setNeutralMode(NeutralMode.Brake);
	}
	
	public void InitializePneumatics()
	{
		solenoid = new Solenoid(RobotMap.Robot.Pneumatics.SOLENOID);
		compressor = new Compressor(RobotMap.Robot.Pneumatics.COMPRESSOR_ID);

		compressor.setClosedLoopControl(true);
	}

	public void setCompressorOff()
	{
		compressor.setClosedLoopControl(false);
		compressor.stop();
	}
	
	public void setCompressorOn()
	{
		compressor.setClosedLoopControl(true);
	}
	
	public void ToggleCompressor()
	{
		compressorState = !compressorState;
		compressor.setClosedLoopControl(compressorState);
	}

	public void RunIntake(double power)
	{
		IntakeWheels.set(ControlMode.PercentOutput, power);
	}

	public void RunElbow(double power)
	{
		IntakeElbow.set(ControlMode.PercentOutput, power);	
	}
	
	public void MoveSolenoid(boolean position)
	{
		solenoid.set(position);
	}

	public void periodic() {}

	@Override
	protected void initDefaultCommand() {}
}

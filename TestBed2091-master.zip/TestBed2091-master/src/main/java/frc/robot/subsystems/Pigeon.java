package frc.robot.subsystems;
	
	import com.ctre.phoenix.sensors.PigeonIMU;
	
	import edu.wpi.first.wpilibj.command.Subsystem;
	import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
	
	import frc.robot.*;
	
public class Pigeon extends Subsystem 
{
	private static Pigeon instance;
	public double initAngle = 0.0;
	public PigeonIMU pigeon;

	@Override
	protected void initDefaultCommand() {}

	public Pigeon() 
	{
        pigeon = new PigeonIMU(0);
		initAngle = pigeon.getFusedHeading();
	}

	public static Pigeon initializePigeon() 
	{
		if (instance == null) 
		{
			instance = new Pigeon();
		}
		return instance;
	}

	public double getFusedAngle() 
	{
		return ((pigeon.getFusedHeading() + initAngle) % 360.0);
	}

	public void periodic() 
	{
		SmartDashboard.putNumber("Robot Angle", Robot.pigeon.getFusedAngle());
	}
}
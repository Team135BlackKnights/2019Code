package frc.robot.subsystems;

	import com.ctre.phoenix.motorcontrol.ControlMode;
	import com.ctre.phoenix.motorcontrol.NeutralMode;
	import com.ctre.phoenix.motorcontrol.can.TalonSRX;
	import com.ctre.phoenix.motorcontrol.can.VictorSPX;
	import com.ctre.phoenix.motorcontrol.FeedbackDevice;
	import com.ctre.phoenix.motorcontrol.StatusFrameEnhanced;
	import com.ctre.phoenix.motorcontrol.VelocityMeasPeriod;

	import edu.wpi.first.wpilibj.command.Subsystem;
	import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
	import edu.wpi.first.wpilibj.Timer;

	import frc.robot.*;
	import frc.robot.commands.*;

public class Lift extends Subsystem 
{
    public static Lift instance;
    
    public TalonSRX leftLiftTalon, rightLiftTalon;
    public VictorSPX leftLiftVictor, rightLiftVictor;

	public static TalonSRX leadMotor;

	private boolean isPositionInitialized = false;
	
	public boolean isMantaining;
	public double kP =0.0f;

	public double setpoint =0.0;

    private Lift()
    {
		
    	leftLiftTalon = new TalonSRX(RobotMap.Robot.Lift.LEFT_TALON);
    	rightLiftTalon = new TalonSRX(RobotMap.Robot.Lift.RIGHT_TALON);
    	leftLiftVictor = new VictorSPX(RobotMap.Robot.Lift.LEFT_VICTOR);
    	rightLiftVictor = new VictorSPX(RobotMap.Robot.Lift.RIGHT_VICTOR);

		leadMotor = leftLiftTalon;

		initializeTalon(leftLiftTalon , RobotMap.Robot.Lift.LEFT_TALON);
		initializeTalon(rightLiftTalon, RobotMap.Robot.Lift.RIGHT_TALON);
		initializeVictor(leftLiftVictor, RobotMap.Robot.Lift.LEFT_VICTOR);
		initializeVictor(rightLiftVictor, RobotMap.Robot.Lift.RIGHT_VICTOR);
		leadMotor.setSensorPhase(true);
		leadMotor.setSensorPhase(true);
		leadMotor.configSelectedFeedbackSensor(FeedbackDevice.QuadEncoder, 0, 10);
		leadMotor.setStatusFramePeriod(StatusFrameEnhanced.Status_3_Quadrature, 10, 10);
		leadMotor.setSelectedSensorPosition(0, 0, 10);
		
		leadMotor.configVelocityMeasurementPeriod(VelocityMeasPeriod.Period_100Ms, 10);
		leadMotor.configVelocityMeasurementWindow(64, 10); //Might want to check this later
		
		leadMotor.configReverseSoftLimitThreshold(0, 10);
		
		leadMotor.configReverseSoftLimitEnable(true, 10);
	} 	

	public static Lift initializeLift() 
	{if (instance == null) { instance = new Lift(); } return instance;}

	public void initializeTalon(TalonSRX talon, int Talon_id)
    {
		talon.setNeutralMode(NeutralMode.Brake);
		if(!(Talon_id == leadMotor.getDeviceID()))
		{
			talon.follow(leadMotor);
		}
    }

    public void initializeVictor(VictorSPX victor, int Victor_id)
  	{
		victor.setNeutralMode(NeutralMode.Brake);

		if(!(Victor_id == leadMotor.getDeviceID()))
		{
			victor.follow(leadMotor);
		}
   }
	
	public double getEncoderVelocity()
	{
		return (double)leadMotor.getSelectedSensorVelocity(0);
	}
	
	public double getEncoderPosition()
	{
		return (double)leadMotor.getSelectedSensorPosition(0);
	}
	
	public void RunLift(double power) 
	{
		leftLiftTalon.set(ControlMode.PercentOutput, power);
		rightLiftTalon.set(ControlMode.PercentOutput, power);
		leftLiftVictor.set(ControlMode.PercentOutput, power);
		rightLiftVictor.set(ControlMode.PercentOutput, power);
	}
	
	public void initPosition()
	{
		if (!isPositionInitialized)
		{
			Timer timer = new Timer();
			timer.start();
			do
			{
				RunLift(1.0);
			}
			while (timer.get() < 5);
			timer.stop();
			timer.reset();
			isPositionInitialized = true;
		}
	}

	public void setToPosition(double position)
	{	
		Timer timer = new Timer();
		timer.start();

		if (position == getEncoderPosition())
		{
			return;
		}

		double direction = (position < getEncoderPosition()) ? -1 : 1;

		if (direction == 1)
		{
			while(getEncoderPosition() < position && timer.get() < 3)
			{
				RunLift(1 * direction);
			}
		}
		else
		{
			while(getEncoderPosition() > position && timer.get() < 3)
			{
				RunLift(1 * direction);
			}
		}


		timer.stop();
		timer.reset();

		setpoint = position;
	}

	public void periodic() 
	{
		SmartDashboard.putNumber("ManipJoystick Y ", Robot.oi.GetJoystickYValue(RobotMap.OI.MANIP_JOYSTICK));
		SmartDashboard.putNumber("Lift Value", leftLiftTalon.getMotorOutputPercent());
	}
	@Override
	protected void initDefaultCommand() {setDefaultCommand(new RunLift());}
}
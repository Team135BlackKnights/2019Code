package frc.robot.commands;

	import edu.wpi.first.wpilibj.command.Command;

	import frc.robot.*;

public class RunIntakeWheels extends Command
{
	private double _power;

	public RunIntakeWheels(double power)
	{
        this._power = power;
	}
	
	protected void execute()
	{
		Robot.intake.RunIntake(this._power);
	}

	@Override
	protected boolean isFinished() {return isTimedOut();}	
	protected void end() {Robot.intake.RunIntake(0);}
	protected void interrupted() {end();}
}

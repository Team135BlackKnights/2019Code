package frc.robot.commands.DriverAssistance;
	
	import edu.wpi.first.wpilibj.command.CommandGroup;
	
	import frc.robot.Robot;
	
public class DriveandSteer extends CommandGroup 
{
	public DriveandSteer(boolean TurnLeft, int pipeline) 
	{
    	requires(Robot.driveTrain);
		requires(Robot.limelight);

        	addSequential(new LineUp(TurnLeft, pipeline));
			addParallel(new DriveToward(pipeline));
    	}
    }
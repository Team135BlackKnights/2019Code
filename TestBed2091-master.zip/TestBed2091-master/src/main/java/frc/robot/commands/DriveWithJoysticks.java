package frc.robot.commands;

    import edu.wpi.first.wpilibj.command.Command;
    
    import frc.robot.*;
    
public class DriveWithJoysticks extends Command 
{

    private double rightJoystickXValue;
    private double rightJoystickYValue;
    private double leftJoystickZValue;

    public DriveWithJoysticks() 
    {
        requires(Robot.driveTrain);
    }

    protected void initialize() 
    {
        Robot.limelight.ConfigLimelight(Robot.limelight.VISION_PIPELINE, Robot.limelight.LED_OFF);
    }

    protected void execute() 
    {
        rightJoystickYValue = Robot.oi.GetJoystickYValue(RobotMap.OI.RIGHT_JOYSTICK);
        rightJoystickXValue = -Robot.oi.GetJoystickXValue(RobotMap.OI.RIGHT_JOYSTICK);
        leftJoystickZValue = -Robot.oi.GetJoystickZValue(RobotMap.OI.LEFT_JOYSTICK);
     
        Robot.driveTrain.CartesianDrive(rightJoystickXValue, rightJoystickYValue, leftJoystickZValue);
        /* 
        if(swapControls == true)
        {
            Robot.driveTrain.CartesianDrive(RightJoystickXValue, RightJoystickYValue, leftJoystickZValue);
        }
        else 
        {
            RightJoystickXValue = (Robot.navx.getFusedAngle() % 180) > 45 && (Robot.navx.getFusedAngle() % 180) < 135 ? RightJoystickXValue * -1 : RightJoystickXValue;
            RightJoystickYValue = (Robot.navx.getFusedAngle() % 180) > 45 && (Robot.navx.getFusedAngle() % 180) < 135 ? RightJoystickYValue * -1 : RightJoystickYValue;
            Robot.driveTrain.CartesianDrive(RightJoystickXValue, RightJoystickYValue, leftJoystickZValue*.35, -Robot.pigeon.getFusedAngle());
        }
        */
    }
    protected boolean isFinished() {return false;}
    protected void end() {Robot.driveTrain.StopMotors();}
    protected void interrupted() {end();}
}

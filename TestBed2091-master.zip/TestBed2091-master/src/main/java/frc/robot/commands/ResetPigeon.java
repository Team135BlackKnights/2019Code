package frc.robot.commands;

    import edu.wpi.first.wpilibj.command.InstantCommand;
    import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

    import frc.robot.Robot;

public class ResetPigeon extends InstantCommand 
{

    public ResetPigeon() 
    {
        super();
    }

    protected void initialize() 
    {
    	Robot.pigeon.initAngle = 0;
        SmartDashboard.putString("pigeon", "Is Resetting");
    }
}
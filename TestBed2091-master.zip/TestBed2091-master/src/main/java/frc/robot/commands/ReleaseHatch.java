package frc.robot.commands;

	import edu.wpi.first.wpilibj.command.Command;

	import frc.robot.*;

public class ReleaseHatch extends Command
{
	public ReleaseHatch()
	{
        setTimeout(RobotMap.Robot.Timeouts.INTAKE_TIMEOUT);
	}

	protected void execute()
	{
		Robot.intake.MoveSolenoid(true);
	}

	@Override
	protected boolean isFinished() {return isTimedOut();}	
	protected void end() {Robot.intake.MoveSolenoid(false);}
	protected void interrupted() {end();}
}

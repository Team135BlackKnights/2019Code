package frc.robot.commands;

    import edu.wpi.first.wpilibj.command.Command;

    import frc.robot.Robot;
    import frc.robot.subsystems.Limelight;

public class GetLimelightData extends Command 
{
    
    public double[] limelightData = new double[Limelight.NUMBER_OF_LIMELIGHT_CHARACTERISTICS];
    
    public GetLimelightData()
    {
        requires(Robot.limelight);
    }

    protected void initialize()
    {
    	Robot.limelight.SetCameraMode(Limelight.VISION_PROCESSOR);
    	Robot.limelight.SetLEDMode(Limelight.LED_ON);  
    }

    protected void execute()
    {
    	limelightData = Robot.limelight.GetLimelightData();
    }

    protected boolean isFinished(){return false;} 
    protected void end() {}
    protected void interrupted() {}
}

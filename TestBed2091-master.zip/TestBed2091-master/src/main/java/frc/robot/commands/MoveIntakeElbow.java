package frc.robot.commands;

	import edu.wpi.first.wpilibj.command.Command;

	import frc.robot.*;
	
public class MoveIntakeElbow extends Command
{
	private double _power;
	public double timeout;

	public MoveIntakeElbow(double power)
	{
		timeout = RobotMap.Robot.Timeouts.INTAKE_TIMEOUT;

		requires(Robot.intake);
		setTimeout(timeout);

		this._power = power;
	}

	protected void execute()
	{
		Robot.intake.RunElbow(this._power);
	}
	
	@Override
	protected boolean isFinished() {return isTimedOut();}	
	protected void end() {Robot.intake.RunElbow(0);}
	protected void interrupted() {end();}
}

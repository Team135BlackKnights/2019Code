package frc.robot.util;

public interface FunctionalDoubleManager 
{
	public double get();
}


package frc.robot;

import edu.wpi.first.wpilibj.TimedRobot;
import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.command.Scheduler;
import frc.robot.subsystems.*;
import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import frc.robot.subsystems.NavX;

public class Robot extends TimedRobot 
{
	public static OI oi;
	public static DriveTrain driveTrain;
	public static Lift lift;
	public static Intake intake; 
	public static EndGame endgame;
	public static Limelight limelight;
	public static UltrasonicSensor ultrasonic;
	public static NavX navx;
	public static Pigeon pigeon;

	Command m_autonomousCommand;
	SendableChooser<Command> m_chooser = new SendableChooser<>();

	@Override
	public void robotInit() 
	{
		oi = OI.initializeOperatorInterface();
		driveTrain = DriveTrain.initializeDriveTrain();
		lift = Lift.initializeLift();
		intake = Intake.InitializeIntake();
		endgame = EndGame.initializeEndGame();
		limelight = Limelight.initializeLimelight();
		//ultrasonic = UltrasonicSensor.getInstance();
		navx = NavX.initializeNavX();
		pigeon = Pigeon.initializePigeon();
		OI.initializeButtonsWithCommands();
	}
	

	@Override
	public void disabledInit() {
		Robot.limelight.SetLEDMode(Limelight.LED_OFF);
	}

	@Override
	public void disabledPeriodic() 
	{
		Scheduler.getInstance().run();
	}

	@Override
	public void autonomousInit() {}

	@Override
	public void autonomousPeriodic() 
	{
		Scheduler.getInstance().run();
	}

	@Override
	public void teleopInit() 
	{
		if (m_autonomousCommand != null) 
		{
			m_autonomousCommand.cancel();
		}
	}

	@Override
	public void teleopPeriodic() 
	{
		Scheduler.getInstance().run();
	}

	@Override
	public void testPeriodic() {}
}

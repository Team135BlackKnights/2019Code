package org.usfirst.frc.team135.robot.commands.auto;

import org.usfirst.frc.team135.robot.Robot;

import edu.wpi.first.wpilibj.Preferences;
import edu.wpi.first.wpilibj.command.InstantCommand;



public class AutonomousArmTest extends InstantCommand {
	
	Preferences prefs;
	double armPosition;
    public AutonomousArmTest() {
        requires(Robot.arm);
    }

    protected void initialize() {
    	Robot.arm.ResetEncoders();
    	prefs = Preferences.getInstance();
		armPosition = prefs.getDouble("ArmPosition", 1.0);
    }

    protected void execute() {
    	Robot.arm.setToPosition(armPosition);
    }

    protected boolean isFinished() {
        return false;
    }

}

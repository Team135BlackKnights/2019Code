package org.usfirst.frc.team135.robot.subsystems;

import org.usfirst.frc.team135.robot.RobotMap.DRIVETRAIN;
import org.usfirst.frc.team135.robot.commands.tele.DriveWithJoystick;

import com.ctre.phoenix.motorcontrol.FeedbackDevice;
import com.ctre.phoenix.motorcontrol.can.WPI_TalonSRX;
import com.ctre.phoenix.motorcontrol.can.WPI_VictorSPX;

import edu.wpi.first.wpilibj.SpeedControllerGroup;
import edu.wpi.first.wpilibj.command.Subsystem;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

public class DriveTrain extends Subsystem {

	private static DriveTrain _instance;

	public static WPI_TalonSRX
	_backLeftMotor, 
	_frontRightMotor;

	public static WPI_VictorSPX
	_frontLeftMotor,
	_backRightMotor;
	public static DifferentialDrive _chassis;
	
	private DriveTrain()
	{		
		_backLeftMotor = new WPI_TalonSRX(DRIVETRAIN.BACK_LEFT_ID);
		_frontRightMotor = new WPI_TalonSRX(DRIVETRAIN.FRONT_RIGHT_ID);
		_frontRightMotor.configSelectedFeedbackSensor(FeedbackDevice.CTRE_MagEncoder_Absolute, 0, 10);
		
		_backRightMotor = new WPI_VictorSPX(DRIVETRAIN.BACK_RIGHT_ID);
		_frontLeftMotor = new WPI_VictorSPX(DRIVETRAIN.FRONT_LEFT_ID);
		
		SpeedControllerGroup left = new SpeedControllerGroup(_frontLeftMotor, _backLeftMotor);
		SpeedControllerGroup right = new SpeedControllerGroup(_frontRightMotor, _backRightMotor);
		
		_chassis = new DifferentialDrive(left, right);
	}
	
    public void initDefaultCommand() 
    {
    	setDefaultCommand(new DriveWithJoystick());
    }
    
    public void TankDrive(double leftMotorPower, double rightMotorPower) 
	{
		_chassis.tankDrive(leftMotorPower, rightMotorPower);
	}	
    
    public double returnVelocity()
    {
    	return _frontRightMotor.getSelectedSensorVelocity(0);
    }
    
    public void ResetEncoders()
    {
    	_frontRightMotor.setSelectedSensorPosition(0, 0, 10);
    }
    
    public void periodic()
	{
		SmartDashboard.putNumber("Encoder Velocity", returnVelocity());
	}
    
    public static DriveTrain getInstance()
    {
    	if (_instance == null)
		{
			_instance = new DriveTrain();
		}
		return _instance;
    }
}


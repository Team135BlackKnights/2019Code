package org.usfirst.frc.team135.robot.subsystems;

import org.usfirst.frc.team135.robot.RobotMap.ARM;
import org.usfirst.frc.team135.robot.commands.tele.RunArm;

import com.ctre.phoenix.motorcontrol.ControlMode;
import com.ctre.phoenix.motorcontrol.NeutralMode;
import com.ctre.phoenix.motorcontrol.can.WPI_TalonSRX;
import com.ctre.phoenix.motorcontrol.can.WPI_VictorSPX;

import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.command.Subsystem;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

public class Arm extends Subsystem {
	
	private static Arm instance; 
		
	public static WPI_TalonSRX 
	armTalon; 
	public static WPI_VictorSPX 
	armVictor1, 
	armVictor2;
		
	private Arm()
	{
		armTalon = new WPI_TalonSRX(ARM.TALON_ID);
		armVictor1 = new WPI_VictorSPX(ARM.ARM_VICTOR_ID_1);
		armVictor2 = new WPI_VictorSPX(ARM.ARM_VICTOR_ID_2);
		
		armVictor1.follow(armTalon);
		armVictor2.follow(armTalon);
	}
	
	public double getEncoderVelocity()
	{
		return (double)armTalon.getSelectedSensorVelocity(0);
	}
	
	public double getEncoderPosition()
	{
		return (double)armTalon.getSelectedSensorPosition(0);
	}
	
	public void RunArmMotors(double power) 
	{
		armTalon.set(power);
	}
	
	public void ResetEncoders()
	{
		armTalon.setSelectedSensorPosition(0, 0, 10);
	}
	
	public void setToPosition(double position)
	{
		Timer timer = new Timer();
		timer.start();
		if (position == getEncoderPosition())
		{
			return;
		}
		double direction = (position < getEncoderPosition()) ? -1 : 1;
		
		if (direction == 1)
		{
			while(getEncoderPosition() < position && timer.get() < 3)
			{
				armTalon.set(ControlMode.PercentOutput, 1.0);
			}
		}
		else
		{
			while(getEncoderPosition() > position && timer.get() < 3)
			{
				armTalon.set(ControlMode.PercentOutput, -1.0);
			}
		}
	}
	
	protected void initDefaultCommand() {
		setDefaultCommand(new RunArm());
	}
	
	public static Arm getInstance()
	{
		if (instance == null)
		{
			instance = new Arm();
		}
		return instance; 
	}
	
	public void periodic()
	{
		SmartDashboard.putNumber("Arm Position", getEncoderPosition());
		SmartDashboard.putNumber("Arm Velocity", getEncoderVelocity());
	}
}

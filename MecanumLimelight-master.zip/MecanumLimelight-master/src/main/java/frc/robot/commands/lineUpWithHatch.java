/*----------------------------------------------------------------------------*/
/* Copyright (c) 2018 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot.commands;

import edu.wpi.first.wpilibj.command.Command;
import frc.robot.Robot;
import frc.robot.subsystems.Limelight;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

public class lineUpWithHatch extends Command {
  public lineUpWithHatch() {
    requires(Robot.limelight);
    requires(Robot.driveTrain);
  }

  @Override
  protected void initialize() {
    Robot.limelight.SetCameraPipeline(Limelight.HATCH_PIPELINE);
    Robot.limelight.SetCameraMode(Limelight.VISION_PROCESSOR);
  }

  @Override
  protected void execute() {
    if (Limelight.limelightData[Limelight.VALID_TARGET] > 0.0)
    {
      Robot.driveTrain.driveMecanum(0, Limelight.limelightData[Limelight.HORIZONTAL_OFFSET] / 27 * .5, 0);
    }
    else 
    {
      Robot.driveTrain.driveMecanum(0.0, 0.5, 0);
    }
    SmartDashboard.putNumber("line up with hatch value", Limelight.limelightData[Limelight.HORIZONTAL_OFFSET] / 27 * .5);
  }

  @Override
  protected boolean isFinished() {
    return true;
  }

}

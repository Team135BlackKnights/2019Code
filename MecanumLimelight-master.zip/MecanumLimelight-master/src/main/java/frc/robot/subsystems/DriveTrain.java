/*----------------------------------------------------------------------------*/
/* Copyright (c) 2018 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot.subsystems;

import edu.wpi.first.wpilibj.command.Subsystem;
import edu.wpi.first.wpilibj.drive.MecanumDrive;
import frc.robot.commands.*;
import frc.robot.RobotMap.DRIVETRAIN;
import com.revrobotics.*;
public class DriveTrain extends Subsystem {
  public static DriveTrain instance;
  CANSparkMax frontLeft = new CANSparkMax(DRIVETRAIN.frontLeftID, DRIVETRAIN.BRUSHLESS);
  CANSparkMax frontRight = new CANSparkMax(DRIVETRAIN.frontRightID, DRIVETRAIN.BRUSHLESS);
  CANSparkMax backLeft = new CANSparkMax(DRIVETRAIN.backLeftID, DRIVETRAIN.BRUSHLESS);
  CANSparkMax backRight = new CANSparkMax(DRIVETRAIN.backRightID, DRIVETRAIN.BRUSHLESS);
  MecanumDrive mecanumDrive = new MecanumDrive(frontLeft, backLeft, frontRight, backRight);

  public void driveMecanum(double ySpeed, double xSpeed, double zSpeed)
  {
    mecanumDrive.driveCartesian(ySpeed, xSpeed, zSpeed);
  }
  public static DriveTrain getInstance()
  {if (instance == null){instance = new DriveTrain();}return instance;}

  @Override
  public void initDefaultCommand() {setDefaultCommand(new DriveWithJoysticks());}
}

/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017-2018 FIRST. All Rights Reserved.                        */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot;

import com.revrobotics.CANSparkMaxLowLevel;

/**
 * The RobotMap is a mapping from the ports sensors and actuators are wired into
 * to a variable name. This provides flexibility changing wiring, makes checking
 * the wiring easier and significantly reduces the number of magic numbers
 * floating around.
 */
public class RobotMap {
  public interface K_OI
  {
    public static final int 
      X_JOYSTICK = 0,
      Y_JOSTICK = 1,
      SPIN_JOSTICK = 2,
      TRIGGER_BUTTON = 1;
    public double DRIVE_TRAIN_JOYSTICK_DEADBAND = .15;
  }
  public interface DRIVETRAIN
  {
    public static final int
      frontLeftID = 0,
      frontRightID = 1,
      backLeftID = 2,
      backRightID = 3;
    public static final CANSparkMaxLowLevel.MotorType 
      BRUSHLESS = CANSparkMaxLowLevel.MotorType.kBrushed;
  }
}

/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017-2018 FIRST. All Rights Reserved.                        */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot;

import edu.wpi.first.wpilibj.TimedRobot;
import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.command.Scheduler;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import frc.robot.commands.DriveWithJoysticks;
import frc.robot.commands.GetLimelightData;
import frc.robot.commands.driveTowardsHatch;
import frc.robot.commands.lineUpWithHatch;
import frc.robot.subsystems.*;
public class Robot extends TimedRobot {
  public static OI oi;
  public static DriveTrain driveTrain;
  public static Limelight limelight;
  Command m_autonomousCommand;
  Command l_autonomousCommand;
  @Override
  public void robotInit() {
    oi = new OI();
    driveTrain = new DriveTrain();
    limelight = new Limelight();
  }

  @Override
  public void robotPeriodic() {}

  @Override
  public void disabledInit() {}

  @Override
  public void disabledPeriodic() {
    Scheduler.getInstance().run();
  }
  @Override
  public void autonomousInit() {
  }

  @Override
  public void autonomousPeriodic() {
    Scheduler.getInstance().run();
  }

  @Override
  public void teleopInit() {
    if (m_autonomousCommand != null) {
      m_autonomousCommand.cancel();
    }
  }

  @Override
  public void teleopPeriodic() {
    l_autonomousCommand = new GetLimelightData();
    l_autonomousCommand.start();
    m_autonomousCommand = new DriveWithJoysticks();
    SmartDashboard.putString("Teleop Command Running", "DriveWithJoystick");
    if (OI.isTriggerPressed())
    {
      m_autonomousCommand = new lineUpWithHatch();
      SmartDashboard.putString("Teleop Command Running", "lineUpWithHatch");
      if (Limelight.limelightData[Limelight.HORIZONTAL_OFFSET] < 1.0)
      {
        m_autonomousCommand = new driveTowardsHatch();
        SmartDashboard.putString("Teleop Command Running", "driveTowardsHatch");
      }
    }
    
    m_autonomousCommand.start();
  }

  @Override
  public void testPeriodic() {}
}

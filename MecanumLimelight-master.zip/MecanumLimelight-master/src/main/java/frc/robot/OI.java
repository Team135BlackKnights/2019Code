/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017-2018 FIRST. All Rights Reserved.                        */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/
package frc.robot;

import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.buttons.JoystickButton;
import frc.robot.RobotMap.K_OI;;
public class OI {
	private static Joystick leftJoystick = new Joystick(K_OI.X_JOYSTICK);
  private static Joystick rightJoystick = new Joystick(K_OI.Y_JOSTICK);
  private static Joystick spinJoystick = new Joystick(K_OI.SPIN_JOSTICK);
	private static JoystickButton rightTrigger = new JoystickButton(rightJoystick, K_OI.TRIGGER_BUTTON);
			
  public static OI instance;
  
  private double DeadbandJoystickValue(double joystickValue)
	{
    return Math.abs(joystickValue) >= K_OI.DRIVE_TRAIN_JOYSTICK_DEADBAND ?
     joystickValue : 0.0;
  }
  
  public double[] getJoystickValues()
  {
    double[] joystickValues = {DeadbandJoystickValue(leftJoystick.getY()),
      DeadbandJoystickValue(rightJoystick.getY()),
      DeadbandJoystickValue(spinJoystick.getTwist())};
    return joystickValues;
  }

  public static boolean isTriggerPressed()
	{
		return rightTrigger.get();
	}

  public static OI getInstance()
  {if (instance == null){instance = new OI();}return instance;}
}

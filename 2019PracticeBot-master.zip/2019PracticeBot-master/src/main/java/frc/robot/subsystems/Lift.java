/*----------------------------------------------------------------------------*/
/* Copyright (c) 2018 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot.subsystems;

import com.ctre.phoenix.motorcontrol.ControlMode;
import com.ctre.phoenix.motorcontrol.can.TalonSRX;
import com.ctre.phoenix.motorcontrol.can.VictorSPX;

import edu.wpi.first.wpilibj.command.Subsystem;
import frc.robot.RobotMap.kLift;
import frc.robot.commands.DriveLift;

public class Lift extends Subsystem {
  public static Lift instance;
  private VictorSPX leftVictor = new VictorSPX(kLift.LEFT_VICTOR_ID);
	private VictorSPX rightVictor = new VictorSPX(kLift.RIGHT_VICTOR_ID);

	private TalonSRX leftTalon = new TalonSRX(kLift.LEFT_TALON_ID);
  private TalonSRX rightTalon = new TalonSRX(kLift.RIGHT_TALON_ID);
  public Lift()
  {

  }
  public void DriveLift(double power)
  {
    leftVictor.set(ControlMode.PercentOutput, power); //these values need testing
    rightVictor.set(ControlMode.PercentOutput, -power);
    leftTalon.set(ControlMode.PercentOutput, power);
    rightTalon.set(ControlMode.PercentOutput, -power);
  }
  public int[] getEncoderPosition()
  {
    int[] sensorValues = {leftTalon.getSelectedSensorPosition(0),  rightTalon.getSelectedSensorPosition(0)};
    return sensorValues;
  }
  @Override
  public void initDefaultCommand() {setDefaultCommand(new DriveLift());}
  public static Lift getInstance() {if (instance == null) {instance = new Lift();}return instance;}
}

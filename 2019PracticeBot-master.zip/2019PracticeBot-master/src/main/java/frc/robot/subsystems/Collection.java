/*----------------------------------------------------------------------------*/
/* Copyright (c) 2018 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot.subsystems;

import edu.wpi.first.wpilibj.Compressor;
import edu.wpi.first.wpilibj.DoubleSolenoid;
import edu.wpi.first.wpilibj.command.Subsystem;
import frc.robot.RobotMap.kCollection;


import com.ctre.phoenix.motorcontrol.ControlMode;
import com.ctre.phoenix.motorcontrol.can.*;
public class Collection extends Subsystem {
  public static Collection instance;
	private VictorSPX leftVictor = new VictorSPX(kCollection.LEFT_VICTOR_ID);
	private VictorSPX rightVictor = new VictorSPX(kCollection.RIGHT_VICTOR_ID);

	private TalonSRX talon = new TalonSRX(kCollection.TALON_ID);

  private Compressor compressor = new Compressor(kCollection.COMPRESSOR_ID);

  private DoubleSolenoid pistons = new DoubleSolenoid(kCollection.SOLENOID_IDS[0] ,kCollection.SOLENOID_IDS[1]);
  public Collection()
  {
    compressor.setClosedLoopControl(true);
  }
  public void EjectPanel(DoubleSolenoid.Value value) 
	{
      pistons.set(value);
  }
	public void DriveWheels(double power)
	{
		leftVictor.set(ControlMode.PercentOutput, power);
		rightVictor.set(ControlMode.PercentOutput, power);
	}
	public void MoveCollection(double power)
	{
		talon.set(ControlMode.PercentOutput, power);
  }
  public int getEncoderPosition()
  {
    return talon.getSelectedSensorPosition(0);
  }
		
  @Override
  protected void initDefaultCommand() {}
  public static Collection getInstance() {if (instance == null) {instance = new Collection();}return instance;}
}

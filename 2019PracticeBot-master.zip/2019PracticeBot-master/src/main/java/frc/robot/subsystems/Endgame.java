/*----------------------------------------------------------------------------*/
/* Copyright (c) 2018 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot.subsystems;

import com.ctre.phoenix.motorcontrol.can.VictorSPX;
import com.ctre.phoenix.motorcontrol.ControlMode;

import edu.wpi.first.wpilibj.DoubleSolenoid;
import edu.wpi.first.wpilibj.command.Subsystem;
import frc.robot.RobotMap.kEndgame;


public class Endgame extends Subsystem {
  public static Endgame instance;
  private VictorSPX victor = new VictorSPX(kEndgame.VICTOR_ID);
  private DoubleSolenoid pistons = new DoubleSolenoid(kEndgame.SOLENOID_IDS[0], kEndgame.SOLENOID_IDS[1]);
  public Endgame()
  {
    
  }
  public void DriveCIM(double power)
	{
		victor.set(ControlMode.PercentOutput, power);
  }
  public void SetSolenoid(DoubleSolenoid.Value value) 
	{
      pistons.set(value);
  }
  @Override
  public void initDefaultCommand() {}
  public static Endgame getInstance() {if (instance == null) {instance = new Endgame();}return instance;}
}

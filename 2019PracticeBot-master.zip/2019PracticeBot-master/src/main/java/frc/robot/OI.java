/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017-2018 FIRST. All Rights Reserved.                        */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot;

import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.buttons.JoystickButton;
import frc.robot.RobotMap.K_OI;
import frc.robot.commands.DeployEndgame;
import frc.robot.commands.Eject;
import frc.robot.commands.RunCollectionWheels;

public class OI {
  private static OI instance;
	
	public Joystick[] joysticks = new Joystick[K_OI.NUMBER_OF_JOYSTICKS];
	
	private JoystickButton 
	EJECT_PANEL = new JoystickButton(joysticks[K_OI.MANIP_JOYSTICK_ID], K_OI.EJECT),
	DEPLOY_ENDGAME = new JoystickButton(joysticks[K_OI.MANIP_JOYSTICK_ID], K_OI.DEPLOY_ENDGAME),
	COLLECTION_WHEELS_OUT = new JoystickButton(joysticks[K_OI.MANIP_JOYSTICK_ID], K_OI.COLLECTION_IN),
	COLLECTION_WHEELS_IN = new JoystickButton(joysticks[K_OI.MANIP_JOYSTICK_ID], K_OI.COLLECTION_OUT);
  
  public OI()
	{
		joysticks[RobotMap.K_OI.LEFT_JOYSTICK_ID] = new Joystick(RobotMap.K_OI.LEFT_JOYSTICK_ID);
		joysticks[RobotMap.K_OI.RIGHT_JOYSTICK_ID] = new Joystick(RobotMap.K_OI.RIGHT_JOYSTICK_ID);
		joysticks[RobotMap.K_OI.MANIP_JOYSTICK_ID] = new Joystick(RobotMap.K_OI.MANIP_JOYSTICK_ID);
		
		EJECT_PANEL.whenPressed(new Eject());
		DEPLOY_ENDGAME.whenPressed(new DeployEndgame());
		
		COLLECTION_WHEELS_OUT.whileHeld(new RunCollectionWheels(false));
		COLLECTION_WHEELS_IN.whileHeld(new RunCollectionWheels(true));
  }
	
	private double deadband(double input)
	{
    return Math.abs(input) < K_OI.DEADBAND ? 0 : input;
	}
	// returns an array of joystick x and y values, array[0] = x values, array[1] = y values
	public double[] GetLeftJoystickValues()
	{
		double[] getLeft = {deadband(joysticks[K_OI.LEFT_JOYSTICK_ID].getX()), deadband(joysticks[K_OI.LEFT_JOYSTICK_ID].getY())};
		return getLeft;
	}
	public double[] GetRightJoystickValues()
	{
		double[] getRight = {deadband(-joysticks[K_OI.RIGHT_JOYSTICK_ID].getX()), deadband(joysticks[K_OI.RIGHT_JOYSTICK_ID].getY())};
		return getRight;
	}
	public double[] GetManipJoystickValues()
	{
		double[] getManip = {deadband(joysticks[K_OI.MANIP_JOYSTICK_ID].getX()), deadband(joysticks[K_OI.MANIP_JOYSTICK_ID].getY())};
		return getManip;
  }
  public double GetRightTwist()
	{
		return joysticks[K_OI.RIGHT_JOYSTICK_ID].getTwist();
  }
  public static OI getInstance() {if (instance == null) {instance = new OI();}return instance;}
}

/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017-2018 FIRST. All Rights Reserved.                        */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot;
import com.revrobotics.CANSparkMaxLowLevel;
import com.revrobotics.CANSparkMaxLowLevel.MotorType;

public class RobotMap {
  public interface K_OI
  {
    public static final int 
    LEFT_JOYSTICK_ID = 0,
    MANIP_JOYSTICK_ID = 1,
    RIGHT_JOYSTICK_ID = 2,
    NUMBER_OF_JOYSTICKS = 3,
    EJECT = 6,
    DEPLOY_ENDGAME = 4,
    COLLECTION_OUT = 3,
    COLLECTION_IN = 2;
    public static final double
    DEADBAND = .15;
  }
  public interface kDrivetrain
  {
    public static final int 
    FRONT_LEFT_SPARK_ID = 0,
    FRONT_RIGHT_SPARK_ID = 1,
    REAR_LEFT_SPARK_ID = 2,
    REAR_RIGHT_SPARK_ID = 3;
    public static final CANSparkMaxLowLevel.MotorType BRUSHLESS =  MotorType.kBrushed;
  }
  public interface kCollection
  {
    public static final int 
    LEFT_VICTOR_ID = 0,
    RIGHT_VICTOR_ID = 1,
    TALON_ID = 2,
    COMPRESSOR_ID = 0,
    NUMBER_OF_PISTONS = 4;
    public static final long
    PISTON_WAIT_TIME = 500;//milliseconds
    public static final int[]
    SOLENOID_IDS = {0, 1}; //IDS go solenoid_1_id_1, solenoid_1_id_2, etc 
  }
  public interface kLift
  {
    public static final int 
    LEFT_VICTOR_ID = 0,
    RIGHT_VICTOR_ID = 1,
    LEFT_TALON_ID = 2,
    RIGHT_TALON_ID = 3;
  }
  public interface kEndgame
  {
    public static final int VICTOR_ID = 0;
    public static final int[]
    SOLENOID_IDS = {0, 1};
  }
}

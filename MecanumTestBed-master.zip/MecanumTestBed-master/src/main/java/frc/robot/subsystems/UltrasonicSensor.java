package frc.robot.subsystems;

import edu.wpi.first.wpilibj.Ultrasonic;
import edu.wpi.first.wpilibj.command.Subsystem;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import frc.robot.RobotMap;

public class UltrasonicSensor extends Subsystem 
{
    public Ultrasonic limelightUltrasonic = new Ultrasonic(RobotMap.Robot.Sensors.LIMELIGHT_ULTRASONIC_PING, RobotMap.Robot.Sensors.LIMELIGHT_ULTRASONIC_ECHO);

    private static UltrasonicSensor instance; 

    public static UltrasonicSensor getInstance()
    {
        if (instance == null)
        {
            instance = new UltrasonicSensor();
        }
        return instance;
    }

    public UltrasonicSensor()
    {
        limelightUltrasonic.setAutomaticMode(true);
    }

    public void getUtlrasonicValue()
    {
       double rangeInches  = limelightUltrasonic.getRangeInches();
        SmartDashboard.putNumber("LimelightUltraSonic range ", rangeInches);
    }

    public void initDefaultCommand()
    {
        
    }
    
    
    public void periodic() 
    {
        getUtlrasonicValue();
    }











































































}

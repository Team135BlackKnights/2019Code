package frc.robot.commands;

import frc.robot.*;

import edu.wpi.first.wpilibj.command.Command;

public class RunEndGame extends Command
{
	int _power;
	public RunEndGame(int power)
	{
		requires(Robot.endgame);
		this._power = power;
	}
	protected void execute()
	{
		if (_power == 1) {
			Robot.endgame.RunEndGame(.85);
		}
		else if (_power == 0)
		{
			Robot.endgame.RunEndGame(-.85);
		}
		else 
		{
			Robot.endgame.RunEndGame(0);
		}
		}
	@Override
	protected boolean isFinished() 
	{
		return false;
	}	
	protected void end()
	{
		Robot.endgame.RunEndGame(0);
	}
	protected void interrupted()
	{
		end();
	}
}

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <iostream>
#include <chrono>
using namespace cv;
using namespace std;

long long getMilli()
{
	return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();	
}

int main() {
	int sockfd, portno, n;
    struct sockaddr_in serv_addr;
    struct hostent *server;
    char buffer[256];
    portno = 27015;
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    server = gethostbyname("10.102.132.50");
    if (server == NULL) {
        fprintf(stderr,"ERROR, no such host\n");
        exit(0);
    }

    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, 
         (char *)&serv_addr.sin_addr.s_addr,
         server->h_length);
    serv_addr.sin_port = htons(portno);
    
    if (connect(sockfd,(struct sockaddr *) &serv_addr,sizeof(serv_addr)) < 0) 
	{
        printf("ERROR connecting");
	}
    //const char* sendbuffer = "this is a test";
    //send(sockfd, sendbuffer, sizeof(buffer), 0);
    
	VideoCapture stream1(1);   //0 is the id of video device.0 if you have only one camera.
	//unconditional loop
	//while (true) 
	//{
		Mat cameraFrame;
		
		stream1.set(CV_CAP_PROP_FRAME_WIDTH, 320);
		stream1.set(CV_CAP_PROP_FRAME_HEIGHT, 240);
		vector<int> compression_params;
    		compression_params.push_back(CV_IMWRITE_PNG_COMPRESSION);
   		compression_params.push_back(9);
		vector<uchar> buf;
		unsigned int startTime;
		unsigned int endTime;
		while(true){
		startTime = getMilli();
		stream1 >> cameraFrame;
		imencode(".png", cameraFrame, buf, compression_params);
		//int  imgSize = cameraFrame.total()*cameraFrame.elemSize();
		//Mat dst = cv::imdecode( cv::Mat(buf), CV_LOAD_IMAGE_COLOR );
		//Mat dst = Mat(buf);
		int dstSize = buf.size();
		printf("%d", dstSize);
		write(sockfd, &dstSize, sizeof(int));
		int result = 0;
			result = send(sockfd, buf.data() , dstSize, 0);
			printf("%d\n", result);
		endTime = getMilli();
		//int imgSize = cameraFrame.total() * cameraFrame.elemSize();
			//send(sockfd, cameraFrame.data, imgSize, 0);
		std::cout << (float)(endTime - startTime) / 1000<< "\n";
		}
		//send(sockfd, dst.data, dstSize, 0);
	//}
	
	return 0;
}
